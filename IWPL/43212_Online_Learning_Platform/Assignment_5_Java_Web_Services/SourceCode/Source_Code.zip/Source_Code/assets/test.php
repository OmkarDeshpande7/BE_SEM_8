<html>
    <body>
        <h3>Your email is : <?php echo $_POST["email"] ?> </h3><br>
        <h3>Your phone is : <?php echo $_POST["phone"] ?> </h3><br>
        <h3>Your password is : <?php echo $_POST["password"] ?> </h3><br>

    </body>
</html>