package com.spk.questionnaire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    TextView receiver_msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        receiver_msg = (TextView) findViewById(R.id.textView);
        Intent intent = getIntent();
        String str = intent.getStringExtra("result");
        if (str.equals("2"))
            receiver_msg.setText("You have higher probability of being infected. Please consult nearest doctor.");
        else
            receiver_msg.setText("You have low probability of being infected !");
    }
}