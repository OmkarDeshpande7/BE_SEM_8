package com.spk.questionnaire.questions;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.JsonArray;
import com.spk.questionnaire.R;
import com.spk.questionnaire.ResultActivity;
import com.spk.questionnaire.questions.database.AppDatabase;
import com.spk.questionnaire.questions.qdb.QuestionEntity;
import com.spk.questionnaire.questions.qdb.QuestionWithChoicesEntity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import io.reactivex.Completable;
import io.reactivex.CompletableObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class AnswersActivity extends AppCompatActivity
{
    Context context;
    private static final int REQUEST_LOCATION = 1;
    LinearLayout resultLinearLayout;
    List<QuestionEntity> questionsList = new ArrayList<>();
    List<QuestionWithChoicesEntity> questionsWithAllChoicesList = new ArrayList<>();
    private AppDatabase appDatabase;
    private String MyLat, MyLong;
    double[] d = new double[2];
    LocationManager locationManager;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answers);

        context = this;
        appDatabase = AppDatabase.getAppDatabase(this);

        resultLinearLayout = findViewById(R.id.resultLinearLayout);
        toolBarInit();

        getResultFromDatabase();
    }

    private void toolBarInit()
    {
        Toolbar answerToolBar = findViewById(R.id.answerToolbar);
        answerToolBar.setNavigationIcon(R.drawable.ic_arrow_back);
        answerToolBar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private double[] getLocation() {
        if (ActivityCompat.checkSelfPermission(
                AnswersActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                AnswersActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {

            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double longi = locationGPS.getLongitude();
                return new double[]{lat , longi};
            } else {
                System.out.println("Unable to find location.");
                return new double[]{};
            }
        }
        return new double[]{};
    }
    /*After, getting all result you can/must delete the saved results
    although we are clearing the Tables as soon we start the QuestionActivity.*/
    private void getResultFromDatabase()
    {
        Completable.fromAction(() -> {
            questionsList = appDatabase.getQuestionDao().getAllQuestions();
            questionsWithAllChoicesList = appDatabase.getQuestionChoicesDao().getAllQuestionsWithChoices("1");
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new CompletableObserver()
                {
                    @Override
                    public void onSubscribe(Disposable d)
                    {

                    }

                    @Override
                    public void onComplete()
                    {
                        makeJsonDataToMakeResultView();
                    }

                    @Override
                    public void onError(Throwable e)
                    {

                    }
                });
    }

    /*Here, JSON got created and send to make Result View as per Project requirement.
    * Alternatively, in your case, you make Network-call to send the result to back-end.*/
    private void makeJsonDataToMakeResultView()
    {

        try
        {
            JSONArray questionAndAnswerArray = new JSONArray();
            int questionsSize = questionsList.size();
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

            d = getLocation();
            System.out.println(d[0] + " " + d[1]);
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(d[0], d[1], 1);
            String cityName = addresses.get(0).getAddressLine(0);
            Toast.makeText(this, cityName, Toast.LENGTH_SHORT).show();

            if (questionsSize > 0)
            {
                for (int i = 0; i < questionsSize; i++)
                {
                    JSONObject questionName = new JSONObject();
                    questionName.put("question", questionsList.get(i).getQuestion());
                    //questionName.put("question_id", String.valueOf(questionsList.get(i).getQuestionId()));
                    String questionId = String.valueOf(questionsList.get(i).getQuestionId());

                    JSONArray answerChoicesList = new JSONArray();
                    int selectedChoicesSize = questionsWithAllChoicesList.size();
                    for (int k = 0; k < selectedChoicesSize; k++)
                    {
                        String questionIdOfChoice = questionsWithAllChoicesList.get(k).getQuestionId();
                        if (questionId.equals(questionIdOfChoice))
                        {
                            JSONObject selectedChoice = new JSONObject();
                            selectedChoice.put("answer_choice", questionsWithAllChoicesList.get(k).getAnswerChoice());

                            //selectedChoice.put("answer_id", questionsWithAllChoicesList.get(k).getAnswerChoiceId());
                            answerChoicesList.put(selectedChoice);
                        }
                    }
                    questionName.put("selected_answer", answerChoicesList);

                    questionAndAnswerArray.put(questionName);
                }
                JSONObject questionName = new JSONObject();

                questionName.put("question", "Address");
                JSONArray answerChoicesList = new JSONArray();
                JSONObject selectedChoice = new JSONObject();
                selectedChoice.put("answer_choice", cityName);

                //selectedChoice.put("answer_id", questionsWithAllChoicesList.get(k).getAnswerChoiceId());
                answerChoicesList.put(selectedChoice);
                questionName.put("selected_answer", answerChoicesList);
                questionAndAnswerArray.put(questionName);
            }

            questionsAnswerView(questionAndAnswerArray);

        } catch (JSONException | IOException e)
        {
            e.printStackTrace();
        }
    }



    private void questionsAnswerView(JSONArray questionsWithAnswerArray)
    {
        if (questionsWithAnswerArray.length() > 0)
        {
            try
            {
                for (int i = 0; i < questionsWithAnswerArray.length(); i++)
                {
                    String question = questionsWithAnswerArray.getJSONObject(i).getString("question");

                    TextView questionTextView = new TextView(context);
                    questionTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                    questionTextView.setTextColor(ContextCompat.getColor(context, R.color.colorWhite));
                    questionTextView.setPadding(40, 30, 16, 30);
                    questionTextView.setBackgroundColor(ContextCompat.getColor(context, R.color.colorPrimaryDark));
                    questionTextView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    questionTextView.setTypeface(null, Typeface.BOLD);
                    questionTextView.setText(question);

                    resultLinearLayout.addView(questionTextView);

                    JSONArray selectedAnswerJSONArray = questionsWithAnswerArray.getJSONObject(i).getJSONArray("selected_answer");

                    for (int j = 0; j < selectedAnswerJSONArray.length(); j++)
                    {
                        String answer = selectedAnswerJSONArray.getJSONObject(j).getString("answer_choice");
                        String formattedAnswer = "• " + answer; // alt + 7 --> •

                        TextView answerTextView = new TextView(context);
                        answerTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                        answerTextView.setTextColor(ContextCompat.getColor(context, R.color.colorPrimary));
                        answerTextView.setPadding(60, 30, 16, 30);
                        answerTextView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        answerTextView.setBackgroundColor(ContextCompat.getColor(context, R.color.colorWhite));
                        answerTextView.setText(formattedAnswer);

                        View view = new View(context);
                        view.setBackgroundColor(ContextCompat.getColor(context, R.color.colorPrimary));
                        view.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));

                        resultLinearLayout.addView(answerTextView);
                        resultLinearLayout.addView(view);
                    }

                }

            } catch (JSONException e)
            {
                e.printStackTrace();
            }

            RequestQueue queue = Volley.newRequestQueue(this);
            String url ="http://f66d38887935.ngrok.io/";

// Request a string response from the provided URL.
            JsonArrayRequest stringRequest = new JsonArrayRequest(Request.Method.POST, url, questionsWithAnswerArray,
                    new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            System.out.println(response.toString());
                            String answer;
                            Intent intent = new Intent(AnswersActivity.this, ResultActivity.class);
                            try {
                                JSONObject checkObj = response.getJSONObject(0);
                                intent.putExtra("result", checkObj.getString("answer"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            startActivity(intent);
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    System.out.println(error);
                }
            }){

            };

// Add the request to the RequestQueue.
            queue.add(stringRequest);
        }
    }
}